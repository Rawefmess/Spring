package com.example.rawef.entites;

public enum TypeChambre {
    SIMPLE,
    DOUBLE,
    TRIPLE

}
