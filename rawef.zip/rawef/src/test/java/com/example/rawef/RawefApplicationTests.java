package com.example.rawef;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RawefApplicationTests {

    @Test
    void contextLoads() {
    }

}
